<?php
echo "¡Hola mundo!";
?>