function dentroScript()
{
    alert("Estoy dentro del script");
}